<div id="sidebar">

 <ul>

  <!-- Author Information -->

  <li><table width="188" cellpadding="0" cellspacing="0">

	<tr>

		<td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/side-aboutme.gif" width="188" height="35" alt="About Me" /></td>

	</tr>

    <tr>

    <td class="sidebg">

   ضع هنا معلومات عامة عن الموقع.

  </td>

  </tr>

   <tr>

   <td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/sidefoot.gif" width="188" height="13" alt="" /></td>

   </tr>

  </table></li>





  <!-- List of Pages in Blog -->

  <li><table width="188" cellpadding="0" cellspacing="0">

	<tr>

		<td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/side-otherpages.gif" width="188" height="35" alt="Other Pages" /></td>

	</tr>

    <tr>

    <td class="sidebg">

   <ul>

    <?php wp_list_pages('title_li=' ); ?>

   </ul>

    </td>

  </tr>

   <tr>

   <td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/sidefoot.gif" width="188" height="13" alt="" /></td>

   </tr>

  </table></li>





  <!-- Blog Stats -->

  <li><table width="188" cellpadding="0" cellspacing="0">

	<tr>

		<td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/side-blogstats.gif" width="188" height="35" alt="Blog Stats" /></td>

	</tr>

    <tr>

    <td class="sidebg">

   إحصائيات المدونة هنا.

  </td>

  </tr>

   <tr>

   <td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/sidefoot.gif" width="188" height="13" alt="" /></td>

   </tr>

  </table></li>





  <!-- List of Links in Blog -->

  <li><table width="188" cellpadding="0" cellspacing="0">

	<tr>

		<td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/side-links.gif" width="188" height="35" alt="Links" /></td>

	</tr>

    <tr>

    <td class="sidebg">

  <ul>

  <?php get_links_list(); ?>

  </ul>

    </td>

  </tr>

   <tr>

   <td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/sidefoot.gif" width="188" height="13" alt="" /></td>

   </tr>

  </table></li>

 </ul>

</div>





<div id="sidebar2">

 <ul>

<?php /* If this is the frontpage */ if ( is_home() || is_page() ) { ?>

  <!-- Google Ad -->

  <li><table width="188" cellpadding="0" cellspacing="0">

	<tr>

		<td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/side-google.gif" width="188" height="35" alt="Google" /></td>

	</tr>

    <tr>

    <td class="sidebg">

   منطقة إعلانات.

  </td>

  </tr>

   <tr>

   <td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/sidefoot.gif" width="188" height="13" alt="" /></td>

   </tr>

  </table></li>



<?php /* If this is a category archive */ } if (is_category()) { ?>

  <!-- Google Ad -->

  <li><table width="188" cellpadding="0" cellspacing="0">

	<tr>

		<td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/side-google.gif" width="188" height="35" alt="Google" /></td>

	</tr>

    <tr>

    <td class="sidebg">

   منطقة إعلانات.

  </td>

  </tr>

   <tr>

   <td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/sidefoot.gif" width="188" height="13" alt="" /></td>

   </tr>

  </table></li>



<?php /* If this is a monthly archive */ } if (is_month()) { ?>

  <!-- Google Ad -->

  <li><table width="188" cellpadding="0" cellspacing="0">

	<tr>

		<td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/side-google.gif" width="188" height="35" alt="Google" /></td>

	</tr>

    <tr>

    <td class="sidebg">

   منطقة إعلانات.

  </td>

  </tr>

   <tr>

   <td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/sidefoot.gif" width="188" height="13" alt="" /></td>

   </tr>

  </table></li>

<?php } ?>



  <!-- Search Box -->

  <li><table width="188" cellpadding="0" cellspacing="0">

	<tr>

		<td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/side-find.gif" width="188" height="35" alt="Find" /></td>

	</tr>

    <tr>

    <td class="sidebg" align="center">

     <form method="get" action="<?php echo $PHP_SELF; ?>">

   <input type="text" name="s" id="search" size="15" />

   <input type="submit" name="submit" value="<?php _e('Search'); ?>" />

  </form> 

  </td>

  </tr>

   <tr>

   <td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/sidefoot.gif" width="188" height="13" alt="" /></td>

   </tr>

  </table></li>

  <!-- List of Categories in Blog -->

  <li><table width="188" cellpadding="0" cellspacing="0">

	<tr>

		<td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/side-categories.gif" width="188" height="35" alt="Categories" /></td>

	</tr>

    <tr>

    <td class="sidebg">

   <ul>

    <?php list_cats(1, 'all', 'name', 'asc', '', 1, 0, 0, 1, 0, 1, 0,'','','','','') ?>

   </ul>

    </td>

  </tr>

   <tr>

   <td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/sidefoot.gif" width="188" height="13" alt="" /></td>

   </tr>

  </table></li>





  <!-- Admin Links -->

  <li><table width="188" cellpadding="0" cellspacing="0">

	<tr>

		<td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/side-meta.gif" width="188" height="35" alt="Meta" /></td>

	</tr>

    <tr>

    <td class="sidebg">

  <ul>

		<?php wp_register(); ?>
		<li><?php wp_loginout(); ?></li>
		<li><a href="feed:<?php bloginfo('rss2_url'); ?>" title="<?php _e('يستخدم هذا الموقع نظام الخلاصات RSS'); ?>"><?php _e('خلاصات المواضيع RSS'); ?></a></li>
		<li><a href="feed:<?php bloginfo('comments_rss2_url'); ?>" title="<?php _e('آخر التعليقات بنظام الخلاصات RSS'); ?>"><?php _e('خلاصات التعليقات RSS'); ?></a></li>
		<li><a href="http://www.qyasi.com">قياسي</a></li> 
		<?php wp_meta(); ?>

  </ul>

    </td>

  </tr>

   <tr>

   <td><img src="<?php bloginfo('stylesheet_directory'); ?>/images/sidefoot.gif" width="188" height="13" alt="" /></td>

   </tr>

  </table></li>



 </ul>

</div>