<div id="footer">

 <p class="credits">

 <a href="<?php bloginfo('siteurl')?>" title="login">الحقوق محفوظة</a> &copy; <?php bloginfo('name'); ?><br /> تصميم <a href="http://blog-themes.kalinawebdesigns.com/">kalinawebdesigns</a> | تعريب <a href="http://www.qyasi.com" title="قوالب مجانية">قياسي</a>


  <br /><?php echo sprintf(__("الموقع يستخدم <a href='http://wordpress.org' title='%s'><strong>WordPress</strong></a>"), __("Powered by WordPress, state-of-the-art semantic personal publishing platform")); ?>.

 </p>

</div>

<?php do_action('wp_footer', ''); ?>

</body>

</html>

