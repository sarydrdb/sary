<?php include('header.php'); ?>
  <?php include('sidebar.php'); ?>
  <div id="topcontentdouble"></div>
   <div id="content">
     <div class="contentright">
   <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <div class="post">
     <h3>
      <?php the_time('j F, Y',display); ?>  
     </h3>
     <div class="title" id="post-<?php the_ID(); ?>">
      <a href="<?php the_permalink() ?>" rel="bookmark">
       <?php the_title(); ?>
      </a>
     </div>
     <div class="storycontent">
      <?php the_content(__('(المزيد...)')); ?>
     </div><br /><?php wp_link_pages(); ?> 
    </div>
    <?php comments_template(); ?>
    <?php endwhile; else: ?>
    <p><?php _e('المعذرة, ما تبحث عته غير متوفر هنا.'); ?></p>
   <?php endif; ?>
    <div class="postnavigation">
     <div class="right">
      <?php next_post(' % &#187;','','yes') ?>
     </div>
     <div class="left">
      <?php previous_post('&#171; %','','yes') ?>
        </div>
       </div>
      </div> <!--Closes the contentright div-->
     </div> <!-- Closes the content div-->
    <div id="bottomcontentdouble">
    </div>
 </div> <!-- Closes the container div-->
<?php include('footer.php'); ?>