<?php include('header.php'); ?>
  <?php include('sidebar.php'); ?>
  <div id="topcontentdouble"></div>
   <div id="content">
     <div class="contentright">
   <div class="post">
    <?php if (have_posts()) : ?>
     <h2 class="searchresult">التصنيف</h2>
     <?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
     <div class="searchdetails">
      الأرشيف الخاص بتصنيف '<?php echo single_cat_title(); ?>' 
     </div>
      <?php while (have_posts()) : the_post(); ?>
	   <h2 class="searchresult">
        <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">
   	     <?php the_title(); ?>
        </a>
       </h2>
	   <div class="searchinfo">
        <?php _e("("); ?> <?php the_category(' و') ?> <?php _e(")"); ?>
       </div>
       <div class="clearer"> </div>
       <?php the_excerpt() ?>
       <div class="searchinfo">
        <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">
         (لمشاهدة مواضيع مرتبطة إضغط هنا)</a>
       </div>
      <?php endwhile; ?>
     <?php else : ?>
      غير موجود
    <?php endif; ?>
   </div> <!-- This closes the singlepost div-->
   
   <div class="postnavigation">
    <div class="right">
     <?php posts_nav_link('','','مواضيع سابقة + »') ?>
    </div>
    <div class="left">
     <?php posts_nav_link('','« + مواضيع أحدث ','') ?>
        </div>
       </div>
      </div> <!--Closes the contentright div-->
     </div> <!-- Closes the content div-->
    <div id="bottomcontentdouble">
    </div>
 </div> <!-- Closes the container div-->
<?php include('footer.php'); ?>